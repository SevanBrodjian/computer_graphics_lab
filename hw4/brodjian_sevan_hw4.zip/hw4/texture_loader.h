#ifndef HW4_TEXTURE_LOADER_H
#define HW4_TEXTURE_LOADER_H

#include <string>
#include <GL/glew.h>

GLuint load_png_texture(const std::string& filename);

#endif
